#!/bin/bash          

cordova create StampIT com.alten.stampit StampIT
cd StampIT
rm -R www 
cp -R ../stampit_www/ www
cordova platform add android
cordova plugin add ../stampit_plugin/org.apache.cordova.geolocation
cordova plugin add ../stampit_plugin/com.phonegap.plugins.barcodescanner
cordova plugin add ../stampit_plugin/org.apache.cordova.inappbrowser
cordova plugin add ../stampit_plugin/org.apache.cordova.splashscreen
cordova build
#serve a sovrascrivere le icone
cp ../icon.png platforms/android/ant-build/res/drawable
cp ../icon.png platforms/android/ant-build/res/drawable-hdpi
cp ../icon.png platforms/android/ant-build/res/drawable-mdpi
cp ../icon.png platforms/android/ant-build/res/drawable-ldpi
cp ../icon.png platforms/android/ant-build/res/drawable-xhdpi


cp ../screen_land.png platforms/android/ant-build/res/drawable-land-hdpi/screen.png
cp ../screen_land.png platforms/android/ant-build/res/drawable-land-ldpi/screen.png
cp ../screen_land.png platforms/android/ant-build/res/drawable-land-mdpi/screen.png
cp ../screen_land.png platforms/android/ant-build/res/drawable-land-xhdpi/screen.png
cp ../screen_port.png platforms/android/ant-build/res/drawable-port-hdpi/screen.png
cp ../screen_port.png platforms/android/ant-build/res/drawable-port-ldpi/screen.png
cp ../screen_port.png platforms/android/ant-build/res/drawable-port-mdpi/screen.png
cp ../screen_port.png platforms/android/ant-build/res/drawable-port-xhdpi/screen.png

cordova build
cordova run
cd ..
#rm -R -f StampIT
