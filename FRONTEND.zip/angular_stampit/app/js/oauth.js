console.log("importing oauth.js!!!");
var fbapi = {
    authorize: function (options) {

        var deferred = $.Deferred();    

        //Build the OAuth consent page URL
        var authUrl = 'https://www.facebook.com/dialog/oauth?' + $.param({
            client_id: options.client_id,
            redirect_uri: options.redirect_uri
        });

        console.log('about to open InAppBrowser with URL: ' + authUrl);

        //Open the OAuth consent page in the InAppBrowser
        var authWindow = window.open(authUrl, '_blank', 'location=no,toolbar=no');

        $(authWindow).on('loadstart', function (e) {
            var url = e.originalEvent.url;

            console.log('InAppBrowser: loadstart event has fired with url: ' + url);

            var code = /\?code=(.+)$/.exec(url);
            var error = /\?error=(.+)$/.exec(url);

            if (code || error) {
                //Always close the browser when match is found
                authWindow.close();
            }

            if (code) {
                //Exchange the authorization code for an access token
                $.post('https://graph.facebook.com/oauth/access_token', {
                    code: code[1],
                    client_id: options.client_id,
                    client_secret: options.client_secret,
                    redirect_uri: options.redirect_uri
                }).done(function (data) {
                    deferred.resolve(data);
                }).fail(function (response) {
                    deferred.reject(response.responseJSON);
                });
            } else if (error) {
                //The user denied access to the app
                deferred.reject({
                    error: error[1]
                });
            }
        });

        return deferred.promise();
    },

    profile: function (access_token) {
        var deferred = $.Deferred();

        //Build the OAuth consent page URL
        var profile_uri = 'https://graph.facebook.com/me?' + access_token;

        console.log('about to fetch facebook profile: ' + profile_uri);

        $.getJSON(profile_uri)
        .done(function (data) {
            deferred.resolve(data);
        }).fail(function (response) {
            deferred.reject(response.responseJSON);
        });

        return deferred.promise();
    }
};

$(document).on('deviceready', function () {
	console.log("device ready!!!");
    //enable cross site script
    jQuery.support.cors = true;
});

function loginFB() {
	console.log("click!");

	$.when(fbapi.authorize({
		client_id: '441665849309715',
		client_secret: '347f9148d6f989a837ffa8a736491bc2',
		redirect_uri: 'http://localhost/'
	}))
	.then(function (access_token) {
		console.log('Executing then callback with access token: ' + access_token);            
		fbapi.profile(access_token).done(function (data) {
			console.log('facebook response' + JSON.stringify(data));
			alert('facebook response' + JSON.stringify(data));
		}).fail(function (data) {
			console.log("error");
		});
	});
}
